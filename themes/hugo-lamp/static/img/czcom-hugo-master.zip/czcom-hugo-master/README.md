# czcom-hugo
前にチズ氏が<a href="https://chizuchizu.com">chizuchizu.com</a>が遅いと言っていたので、
試しにHugoで作ってみました。

## Theme
lamp  
<a href="https://github.com/huyb1991/hugo-lamp">https://github.com/huyb1991/hugo-lamp</a>

## Site
  
<a href="https://chizu-com.web.app">https://chizu-com.web.app</a>
